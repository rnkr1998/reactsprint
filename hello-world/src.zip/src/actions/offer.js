import axios from '../axios/axios';

const _addOffer = (offer) => ({
    type: 'ADD_Offer',
    offer
});

export const addOffer = (offerData = {
    complaintType: '',
    complaintMessage: '',
    complaintOn: '',
    
}) => {
    return (dispatch) => {
       
        const offer = {
 
            "complaintMessage": "success",
            "complaintOn": "succes",
            "complaintType": "succes",
            "farmer": {
             
              "farmerAddress": "succes",
              "farmerAge": 46,
              "farmerEmail": "string",
              "farmerId": 2,
              "farmerName": "string",
              "farmerNumber": 9567578769
            }
          };

        return axios.post('complain/add', complaint).then(result => {
            dispatch(_addComplaint(result.data));
        });
    };
};








const _getComplaint = (complaint) => ({
    type: 'GET_COMPLAINT',
    complaint
});

export const getComplaints = () => {
    return (dispatch) => {
        return axios.get('complaint').then(result => {
            const complaint = [];

            result.data.forEach(item => {
                complaint.push(item);
            });

            dispatch(_getComplaint(complaint));
        });
    };
};
