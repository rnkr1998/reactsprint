import React from 'react';
import ComplaintForm from './ComplaintForm';
import { connect } from 'react-redux';
import { addComplaint } from '../../actions/complaint';
import {ViewComplaint} from './ViewComplaint';
const AddComplaints = (props) => (
   
        <div>
        <ComplaintForm
        onSubmitComplaint={(complaints) => {
                props.dispatch(addComplaint(complaints));
               // props.history.push('/');
            }}

        /><ViewComplaint/></div>
);

export default connect()(AddComplaints);
