import React from 'react';
import { connect } from 'react-redux';
import { getComplaints } from '../../actions/complaint';

export const ViewComplaint = (props) => (
   
    <div>
        Complaint List:
        <ul>
            {props.complaint.map(complaints => {
                return (
                    <li >
                        <ul>{complaints}</ul>
                    </li>
                );
            })}
        </ul>

    </div>
);

const mapStateToProps = (state) => {
    return {
        complaint: state
    };
}
const mapDispatchToProps = (dispatch) =>{   // to update data to the store via dispatch(action)


    return {

          GetComplaints : ()=>{dispatch(getComplaints())   }

    }


}

export default connect(mapStateToProps,mapDispatchToProps)(ViewComplaint);