import React from 'react';
import OfferForm from './OfferForm';
import { connect } from 'react-redux';
import { addOffer } from '../../actions/offer';

const AddOffer = (props) => (
   
        <div>
        <OfferForm
        onSubmitOffer={(offers) => {
                props.dispatch(addOffer(offers));
               // props.history.push('/');
            }}

        /></div>
);

export default connect()(AddOffers);
